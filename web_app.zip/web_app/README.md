# CalFit 
> CalFit Program is a AI Activity project led by UCB and UCSF

## Staff
* Anil Aswani (UC Berkeley, IEOR, Professor)
* Yoshimi Fukuoka (UCSF, PN, Professor)
* Shixuan (Wayne) Li (UC Berkeley, EECS & IEOR, 2020')
* Wohno Song (UC Berkeley, CogSci, 2021')
* Cinyi Mao (UC Berkeley, ORMS, 2019')
