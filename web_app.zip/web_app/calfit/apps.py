from django.apps import AppConfig


class CalfitConfig(AppConfig):
    name = 'calfit'
